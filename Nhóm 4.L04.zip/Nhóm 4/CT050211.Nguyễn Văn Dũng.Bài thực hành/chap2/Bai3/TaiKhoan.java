package BaiThucHanhOOP.TH2.Bai3;

//Bài 3

import java.util.Scanner;

public class TaiKhoan {
    private String soTaiKhoan;
    private String hoTen;
    private int soTien;

    public TaiKhoan(String soTaiKhoan, String hoTen, int soTien){
        this.soTaiKhoan = soTaiKhoan;
        this.hoTen = hoTen;
        this.soTien = soTien;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setSoTien(int soTien) {
        this.soTien = soTien;
    }

    public String getHoTen() {
        return hoTen;
    }

    public int getSoTien() {
        return soTien;
    }

    public String getSoTaiKhoan() {
        return soTaiKhoan;
    }

    public void napTien(int tien) {
        setSoTien(soTien+tien);
        System.out.println("So du tai khoan cua ban {"+getSoTaiKhoan()+"} sau khi nap "+tien+" = "+getSoTien());
    }

    public void rutTien(int tien) {

        if (tien > soTien) {
            System.out.println("So du tai khoan khong du.");
        } else {
            setSoTien(this.soTien - tien);
            System.out.println("So du tai khoan cua ban {" + getSoTaiKhoan() + "} con: " + getSoTien());
        }
    }

    public void chuyenTien(TaiKhoan taiKhoan,int tien) {
        if (tien > getSoTien()) {
            System.out.println("So du tai khoan khong du.");
        } else {
            setSoTien(this.soTien - tien);
            taiKhoan.napTien(tien);

            System.out.println("So du tai khoan {"+getSoTaiKhoan()+"} con: "+this.getSoTien());

        }
    }
}

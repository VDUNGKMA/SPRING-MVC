package BaiThucHanhOOP.TH2.Bai3;


public class KiemTra {
    public static void main(String[] args) {
        TaiKhoan tk1 = new TaiKhoan("111","Huy",20000);
        TaiKhoan tk2 = new TaiKhoan("123","Hoang",10000);
        tk1.rutTien(25000);

        tk1.napTien(20000);


        tk1.chuyenTien(tk2,5000);
    }
}


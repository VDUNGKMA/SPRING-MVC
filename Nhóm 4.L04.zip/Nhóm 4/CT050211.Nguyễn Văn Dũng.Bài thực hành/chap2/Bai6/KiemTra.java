package BaiThucHanhOOP.TH2.Bai6;



public class KiemTra {
    public static void main(String[] args) {
        Diem tam1 = new Diem(0,0);
        Diem tam2 = new Diem(2,2);
        HinhTron hinhTron1 = new HinhTron(2f,tam1);
        HinhTron hinhTron2 = new HinhTron(4f,tam2);

        System.out.println("Tinh chu vi\n");
        System.out.println("Chu vi hinh tron 1: "+hinhTron1.tinhChuvi());
        System.out.println("Chu vi hinh tron 2: "+hinhTron2.tinhChuvi());

        System.out.println(hinhTron1.toString()+"\n"+hinhTron2.toString());

        System.out.println("Khoang cach 2 hinh tron: "+hinhTron1.tinhKhoangcach(hinhTron2));
    }
}


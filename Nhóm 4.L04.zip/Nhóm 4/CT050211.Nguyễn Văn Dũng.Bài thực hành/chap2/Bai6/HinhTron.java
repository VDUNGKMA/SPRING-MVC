package BaiThucHanhOOP.TH2.Bai6;


public class HinhTron {
    float bankinh;
    Diem tam;

    public HinhTron(){
    }
    public HinhTron(float bankinh,Diem tam){
        this.tam = tam;
        this.bankinh = bankinh;
    }
    public float getBanKinh(){
        return bankinh;
    }
    public Diem getTam() {
        return tam;
    }

    public void setBankinh(float bankinh) {
        this.bankinh = bankinh;
    }
    public void setTam(Diem tam) {
        this.tam = tam;
    }
    public void setToadoTam(int x,int y){
        this.tam.x = x;
        this.tam.y = y;
    }
    public float tinhDientich(){
        final float pi = 3.14f;
        float dienTich = 0;
        dienTich = (float) (pi * Math.pow(bankinh,2));
        return dienTich;
    }

    public float tinhChuvi() {
        final float pi = 3.14f;
        return 2*pi*bankinh;
    }
    public float tinhKhoangcach(HinhTron hinhTron1){
        float kc = 0;
        kc = (float) Math.sqrt(Math.pow(hinhTron1.tam.x-this.tam.x,2)+Math.pow(hinhTron1.tam.y-this.tam.y,2));
        return kc;
    }

    public String toString() {
        return "Hinh Tron co tam toa do: "+tam.toString();
    }
}

package BaiThucHanhOOP.TH2.Bai4;

public class ThoiGian {
    private int gio;
    private int phut;
    private int giay;

    public ThoiGian(int gio, int phut, int giay){
        this.gio = gio;
        this.phut = phut;
        this.giay = giay;
    }

    public void setGiay(int giay){
        this.giay = giay;
    }
    public void setGio(int gio){
        this.gio = gio;
    }
    public void setPhut(int phut){
        this.phut = phut;
    }

    public int getGio(){
        return gio;
    }
    public int getPhut(){
        return phut;
    }
    public int getGiay(){
        return giay;
    }

    public void tang1s(){
        giay = giay + 1;
    }
    public void giam1s(){
        giay = giay - 1;
    }

    public String toString(){
        return "Thoi Gian: "+gio+":"+phut+":"+giay;
    }
}

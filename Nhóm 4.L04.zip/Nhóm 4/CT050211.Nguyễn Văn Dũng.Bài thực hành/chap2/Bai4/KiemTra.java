package BaiThucHanhOOP.TH2.Bai4;


import BaiThucHanhOOP.TH2.Bai1.NhanVien;
import BaiThucHanhOOP.TH2.Bai5.Diem;
import BaiThucHanhOOP.TH2.Bai5.TamGiac;
import BaiThucHanhOOP.TH2.Bai6.HinhTron;
import BaiThucHanhOOP.TH2.Bai7.Sach;
import BaiThucHanhOOP.TH2.Bai7.TacGia;
import BaiThucHanhOOP.TH2.Bai8.HoaDon;
import BaiThucHanhOOP.TH2.Bai9.KhachHang;

public class KiemTra {
    public static void main(String[] args) {
        ThoiGian tg1 = new ThoiGian(12,10,8);
        ThoiGian tg2 = new ThoiGian(21,13,14);
        System.out.println(tg1.toString());
        for (int i = 1; i <= 5; i++){
            tg1.tang1s();
        }
        System.out.println(tg1.toString());
    }
}


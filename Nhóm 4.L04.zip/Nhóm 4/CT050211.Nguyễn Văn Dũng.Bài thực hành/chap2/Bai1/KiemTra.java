package BaiThucHanhOOP.TH2.Bai1;

public class KiemTra {
    public static void main(String[] args) {
        NhanVien nv1 = new NhanVien("111", "Huy", 1202f);
        NhanVien nv2 = new NhanVien("222", "Hoang", 1234);

        nv1.tangLuong(0.5f);
        System.out.println("Luong nv1 Huy: " + nv1.getLuong());

        System.out.println("Ten nv2: " + nv2.getHoTen());
        System.out.println("Luong 1 nam nv2: " + nv2.luong1Nam());
        nv2.setHoTen("Aloalo");
        System.out.println("Ten nv2 moi: " + nv2.getHoTen());
    }
}


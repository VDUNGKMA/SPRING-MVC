package BaiThucHanhOOP.TH2.Bai1;


    public class NhanVien {
        private String maNV;
        private String hoTen;
        private float luong;

        public NhanVien(String s_maNV, String s_hoTen, float f_luong) {
            this.maNV = s_maNV;
            this.hoTen = s_hoTen;
            this.luong = f_luong;
        }

        public String getMaNV() {
            return maNV;
        }

        public String getHoTen() {
            return hoTen;
        }

        public void setHoTen(String hoTen) {
            this.hoTen = hoTen;
        }

        public float getLuong() {
            return luong;
        }

        public void setLuong(float luong) {
            this.luong = luong;
        }

        public float luong1Nam() {
            return luong * 12;
        }

        public float tangLuong(float n) {
            luong = (float) (luong * (1.0 + n));
            return luong;
        }
    }



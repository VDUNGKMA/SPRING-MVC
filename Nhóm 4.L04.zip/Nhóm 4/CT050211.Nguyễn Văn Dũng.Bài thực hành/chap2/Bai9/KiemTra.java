package BaiThucHanhOOP.TH2.Bai9;

public class KiemTra {
    public static void main( String[] args) {
        KhachHang kh1 = new KhachHang("111","Quang Huy","HN");
        TaiKhoan tk1 = new TaiKhoan("abc",20000,kh1);

        System.out.print("Nap tien: "+tk1.napTien()+"\n");
        System.out.print("Rut tien: "+tk1.rutTien()+"\n");
    }
}


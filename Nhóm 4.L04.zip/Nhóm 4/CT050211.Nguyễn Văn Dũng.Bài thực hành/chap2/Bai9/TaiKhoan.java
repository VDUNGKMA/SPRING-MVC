package BaiThucHanhOOP.TH2.Bai9;

import java.util.Scanner;

//Bài 9

public class TaiKhoan {
    private String soTaiKhoan;
    private int soTien;
    KhachHang khachHang;

    public TaiKhoan(String soTaiKhoan,int soTien,KhachHang khachHang){
        this.soTaiKhoan = soTaiKhoan;
        this.soTien = soTien;
        this.khachHang = khachHang;
    }

    public String getSoTaiKhoan() {
        return soTaiKhoan;
    }
    public int getSoTien() {
        return soTien;
    }
    public KhachHang getKhachHang() {
        return khachHang;
    }
    public String gethoTenKhachHang() {
        return khachHang.getTenKhachHang();
    }
    public int napTien() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap so tien nap: ");
        int tienNap = sc.nextInt();

        soTien += tienNap;
        return soTien;
    }
    public int rutTien() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap so tien rut:");
        int tienRut = sc.nextInt();

        while (tienRut > soTien){
            System.out.print("Tai khoan khong du tien. Vui long nhap lai:");
            tienRut = sc.nextInt();
        }

        soTien -= tienRut;
        return soTien;

    }
}

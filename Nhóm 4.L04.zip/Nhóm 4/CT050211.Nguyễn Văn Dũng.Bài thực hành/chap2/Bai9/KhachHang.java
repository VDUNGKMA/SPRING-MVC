package BaiThucHanhOOP.TH2.Bai9;

//Bài 9

public class KhachHang {
    private String maKhachHang;
    private String tenKhachHang;
    private String diaChi;

    public KhachHang(String maKhachHang,String tenKhachHang,String diaChi){
        this.maKhachHang = maKhachHang;
        this.tenKhachHang = tenKhachHang;
        this.diaChi = diaChi;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public String getTenKhachHang() {
        return tenKhachHang;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public void setTenKhachHang(String tenKhachHang) {
        this.tenKhachHang = tenKhachHang;
    }
}


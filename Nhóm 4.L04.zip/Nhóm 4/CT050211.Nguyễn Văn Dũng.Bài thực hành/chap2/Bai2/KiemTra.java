package BaiThucHanhOOP.TH2.Bai2;




public class KiemTra {
    public static void main(String[] args) {

        HoaDon hd = new HoaDon("aaa", "Apple", 100, 50.0);
        System.out.println("Mua " + hd.getSoLuong() + " voi gia " + hd.getDonGia());
        System.out.println("Tong tien: " + hd.tongTien());
    }
}
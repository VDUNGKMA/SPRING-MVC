package BaiThucHanhOOP.TH2.Bai2;



//Bài 2

public class HoaDon {
    private String maHoaDon;
    private String moTa;
    private int soLuong;
    private double donGia;

    public HoaDon(String maHoaDon, String moTa, int soLuong, double donGia) {
        this.maHoaDon = maHoaDon;
        this.moTa = moTa;
        this.soLuong = soLuong;
        this.donGia = donGia;
    }

    public int getSoLuong() {
        return soLuong;
    }
    public String getMaHoaDon() {
        return maHoaDon;
    }
    public String getMoTa() {
        return moTa;
    }
    public double getDonGia() {
        return donGia;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double tongTien(){
        double sum = 0;
        sum = donGia * soLuong;
        return sum;
    }
}

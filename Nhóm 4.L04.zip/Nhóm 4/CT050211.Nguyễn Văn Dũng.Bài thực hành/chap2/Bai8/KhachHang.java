package BaiThucHanhOOP.TH2.Bai8;
//Bài 8

public class KhachHang {
    private String maKhachHang;
    private String hoTen;
    private double giamGia;

    public KhachHang(String maKhachHang, String hoTen, double giamGia){
        this.maKhachHang = maKhachHang;
        this.hoTen = hoTen;
        this.giamGia = giamGia;
    }
    public String getMaKhachHang(){
        return maKhachHang;
    }
    public String getHoTen(){
        return hoTen;
    }
    public double getGiamGia(){
        return giamGia;
    }
    public void setHoTen(String hoTen){
        this.hoTen = hoTen;
    }
    public void setGiamGia(double giamGia){
        this.giamGia = giamGia;
    }

}

package BaiThucHanhOOP.TH2.Bai8;

public class KiemTra {
    public static void main(String[] args) {
        KhachHang kh1 = new KhachHang("123","Huyy",0.20);
        HoaDon hd1 = new HoaDon("aaa",kh1,20000);

        System.out.print("So tien phai tra la (soTien*giamGia): "+hd1.tinhTienTra());
    }
}


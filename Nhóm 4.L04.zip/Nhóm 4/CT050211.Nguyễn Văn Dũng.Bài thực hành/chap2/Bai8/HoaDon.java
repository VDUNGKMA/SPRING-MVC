package BaiThucHanhOOP.TH2.Bai8;


//Bài 8
public class HoaDon {
    private String maHoaDon;
    KhachHang khachHang;
    private double tienTra;

    public HoaDon(String maHoaDon, KhachHang khachHang, double tienTra){
        this.maHoaDon = maHoaDon;
        this.khachHang = khachHang;
        this.tienTra = tienTra;
    }
    public String getMaHoaDon(){
        return maHoaDon;
    }
    public KhachHang getKhachHang(){
        return khachHang;
    }
    public double getTienTra(){
        return tienTra;
    }
    public String getHoTenKhachHang(){
        return khachHang.getHoTen();
    }
    public void setTienTra(double tienTra){
        this.tienTra = tienTra;
    }
    public double tinhTienTra(){
        tienTra = tienTra - ( tienTra * khachHang.getGiamGia());
        return tienTra;

    }
}
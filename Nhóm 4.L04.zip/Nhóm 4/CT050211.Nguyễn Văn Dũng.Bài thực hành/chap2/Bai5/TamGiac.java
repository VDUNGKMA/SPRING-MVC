package BaiThucHanhOOP.TH2.Bai5;

import BaiThucHanhOOP.TH2.Bai5.Diem;

public class TamGiac {
    Diem diem_1;
    Diem diem_2;
    Diem diem_3;

    public TamGiac(float x_1,float y_1,float x_2,float y_2,float x_3,float y_3){
        this.diem_1.x = x_1;
        this.diem_1.y = y_1;

        this.diem_2.x = x_2;
        this.diem_2.y = y_2;

        this.diem_3.x = x_3;
        this.diem_3.y = y_3;
    }
    public TamGiac(Diem diem_1,Diem diem_2,Diem diem_3){
        this.diem_1 = diem_1;
        this.diem_2 = diem_2;
        this.diem_3 = diem_3;
    }
    public boolean isTamGiac() {
        double kc12 = diem_1.khoangCach(diem_2);
        double kc23 = diem_2.khoangCach(diem_3);
        double kc13 = diem_1.khoangCach(diem_3);
        if (kc12+kc23>kc13 && kc12+kc13>kc23 && kc23+kc13>kc12){
            return true;
        }
        return false;
    }
    public double tinhDienTich(){
        double kc12 = diem_1.khoangCach(diem_2);
        double kc23 = diem_2.khoangCach(diem_3);
        double kc13 = diem_1.khoangCach(diem_3);
        double p = (kc12+kc13+kc23)/2;
        double dienTich = Math.sqrt(p*(p-kc13)*(p-kc12)*(p-kc23));

        return dienTich;
    }
    public String toString(){
        return "Tam Giac co 3 diem: \nDiem A:"+diem_1.toString()+"\nDiem B:"+diem_2.toString()+"\nDiem C:"+diem_3.toString();
    }
}

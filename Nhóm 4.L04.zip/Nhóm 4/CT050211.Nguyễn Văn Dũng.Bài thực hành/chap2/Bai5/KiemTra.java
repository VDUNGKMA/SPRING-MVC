package BaiThucHanhOOP.TH2.Bai5;


public class KiemTra {
    public static void main(String[] args) {
        Diem diemA = new Diem(1,2);
        Diem diemB = new Diem(-1,2);
        Diem diemC = new Diem(0,0);
        TamGiac tg = new TamGiac(diemA, diemB, diemC);
        System.out.println(tg.tinhDienTich());
        System.out.println(tg.isTamGiac());
        System.out.println(tg.toString());
    }
}


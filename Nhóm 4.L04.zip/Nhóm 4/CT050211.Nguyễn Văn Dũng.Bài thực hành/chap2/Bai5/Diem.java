package BaiThucHanhOOP.TH2.Bai5;

public class Diem {
    float x;
    float y;

    public Diem(){
    }
    public Diem(float x,float y){
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }
    public double khoangCach(float x,float y){
        double kc = 0;
        kc = Math.sqrt(Math.pow(this.x -x,2)+Math.pow(this.y-y,2));
        return kc;
    }
    public double khoangCach(Diem diem){
        double kc = 0;
        kc = Math.sqrt(Math.pow(diem.x-x,2)+Math.pow(diem.y-y,2));
        return kc;
    }

    public String toString(){
        return  "(" + x + "," + y + ")";
    }

}


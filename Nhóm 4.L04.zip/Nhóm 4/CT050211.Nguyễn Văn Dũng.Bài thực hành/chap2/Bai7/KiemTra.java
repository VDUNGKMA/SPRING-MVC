package BaiThucHanhOOP.TH2.Bai7;


public class KiemTra {
    public static void main(String[] args) {
        TacGia tacGia = new TacGia("001","Huy","dinhhuy@gmail.com","Not null");
        Sach sach1 = new Sach("ali","the skype",tacGia,1000,100);
        System.out.print(sach1.toString());
    }
}


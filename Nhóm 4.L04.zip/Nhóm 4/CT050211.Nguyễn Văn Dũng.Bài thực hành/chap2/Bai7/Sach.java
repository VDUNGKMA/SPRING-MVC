package BaiThucHanhOOP.TH2.Bai7;

import BaiThucHanhOOP.TH2.Bai7.TacGia;

public class Sach {
    private String maSach;
    private String ten;
    TacGia tacGia;
    private int gia;
    private int soTrang;

    public Sach(String maSach,String ten,TacGia tacGia,int gia,int soTrang){
        this.maSach = maSach;
        this.ten = ten;
        this.tacGia = tacGia;
        this.gia = gia;
        this.soTrang = soTrang;
    }

    public int getGia() {
        return gia;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public String getTen() {
        return ten;
    }

    public String getMaSach() {
        return maSach;
    }

    public TacGia getTacGia() {
        return tacGia;
    }
    public void setTen(String ten){
        this.ten = ten;
    }

    public void setGia(int gia) {
        this.gia = gia;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public void setTacGia(TacGia tacGia) {
        this.tacGia = tacGia;
    }

    public String toString(){
        return "||"+maSach+"||"+ten+"||" + tacGia.toString() + "||" + gia + "||" + soTrang;
    }
}

package BaiThucHanhOOP.TH2.Bai7;

public class TacGia {
    private String maTacgia;
    private String ten;
    private String email;
    private String thongTinTacGia;

    public TacGia(String maTacgia,String ten,String email,String thongTinTacGia){
        this.maTacgia = maTacgia;
        this.ten = ten;
        this.email = email;
        this.thongTinTacGia = thongTinTacGia;
    }
    public String getMaTacgia(){
        return maTacgia;
    }
    public String getTen(){
        return ten;
    }
    public String getEmail(){
        return email;
    }
    public String getThongTinTacGia(){
        return thongTinTacGia;
    }
    public void setTen(String ten){
        this.ten = ten;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setThongTinTacGia(String thongTinTacGia){
        this.thongTinTacGia = thongTinTacGia;
    }
    public String toString(){
        return "||"+maTacgia+"||"+ten+"||"+email+"||"+thongTinTacGia;
    }
}

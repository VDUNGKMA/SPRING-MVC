package BaiThucHanhOOP.TH3.Bai2;

public class GiaoVien extends Nguoi {
    private String boMon;
    private String khoa;
    private String hocHam;
    private String hocVi;
    private float luong;

    public GiaoVien(String maSo, String hoTen, String ngaySinh, String diaChi, String boMon, String khoa, String hocHam, String hocVi, float luong) {
        super(maSo, hoTen, ngaySinh, diaChi);
        this.boMon = boMon;
        this.khoa = khoa;
        this.hocHam = hocHam;
        this.hocVi = hocVi;
        this.luong = luong;
    }

    public void setKhoa(String khoa) {
        this.khoa = khoa;
    }

    public void setLuong(float luong) {
        this.luong = luong;
    }

    public void setBoMon(String boMon) {
        this.boMon = boMon;
    }

    public void setHocHam(String hocHam) {
        this.hocHam = hocHam;
    }

    public void setHocVi(String hocVi) {
        this.hocVi = hocVi;
    }

    public String getKhoa() {
        return khoa;
    }

    public float getLuong() {
        return luong;
    }

    public String getBoMon() {
        return boMon;
    }

    public String getHocVi() {
        return hocVi;
    }

    public String getHocHam() {
        return hocHam;
    }

    @Override
    public String toString() {
        return "GiaoVien{" +
                "boMon='" + boMon + '\'' +
                ", khoa='" + khoa + '\'' +
                ", hocHam='" + hocHam + '\'' +
                ", hocVi='" + hocVi + '\'' +
                ", luong=" + luong +
                '}';
    }
}

package BaiThucHanhOOP.TH3.Bai2;

public class SinhVien {
    private String nganh;
    private String khoa;
    private int namNhapHoc;
    private int namTotNghiep;

    public SinhVien() {
    }
    public SinhVien(String nganh,String khoa,int namNhapHoc,int namTotNghiep) {
        this.nganh = nganh;
        this.khoa = khoa;
        this.namNhapHoc = namNhapHoc;
        this.namTotNghiep = namTotNghiep;
    }

    public void setKhoa(String khoa) {
        this.khoa = khoa;
    }

    public void setNamNhapHoc(int namNhapHoc) {
        this.namNhapHoc = namNhapHoc;
    }

    public void setNamTotNghiep(int namTotNghiep) {
        this.namTotNghiep = namTotNghiep;
    }

    public void setNganh(String nganh) {
        this.nganh = nganh;
    }

    public int getNamNhapHoc() {
        return namNhapHoc;
    }

    public int getNamTotNghiep() {
        return namTotNghiep;
    }

    public String getKhoa() {
        return khoa;
    }

    public String getNganh() {
        return nganh;
    }

    @Override
    public String toString() {
        return "SinhVien{" +
                "nganh='" + nganh + '\'' +
                ", khoa='" + khoa + '\'' +
                ", namNhapHoc=" + namNhapHoc +
                ", namTotNghiep=" + namTotNghiep +
                '}';
    }
}

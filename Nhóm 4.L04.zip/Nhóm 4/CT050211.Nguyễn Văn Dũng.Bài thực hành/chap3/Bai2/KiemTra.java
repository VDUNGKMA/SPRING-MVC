package BaiThucHanhOOP.TH3.Bai2;

public class KiemTra {
    public static void main(String[] args) {
        GiaoVien gv = new GiaoVien("111","Huy","02-12-2002","HN","ToanHoc","TuNhien","PhGS","ThS",2000f);

        System.out.print("\n"+gv.toString());
    }
}

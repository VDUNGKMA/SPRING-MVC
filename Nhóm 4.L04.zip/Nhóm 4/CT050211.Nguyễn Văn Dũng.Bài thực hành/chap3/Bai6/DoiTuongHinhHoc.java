package BaiThucHanhOOP.TH3.Bai6;

public interface DoiTuongHinhHoc {
    public abstract float tinhDienTich();
    public abstract float tinhChuVi();
}

package BaiThucHanhOOP.TH3.Bai6;

public interface ThayDoiKichThuoc {
    public abstract float thayDoiKt(float thaydoi);
}

package BaiThucHanhOOP.TH3.Bai6;

public class KiemTra {
    public static void main(String[] args) {
        HinhTron a = new HinhTron(2f);
        System.out.println(a.tinhChuVi());
        HinhTronThayDoi a_1 = new HinhTronThayDoi(2.5f);
        System.out.println(a_1.tinhChuVi());
    }
}

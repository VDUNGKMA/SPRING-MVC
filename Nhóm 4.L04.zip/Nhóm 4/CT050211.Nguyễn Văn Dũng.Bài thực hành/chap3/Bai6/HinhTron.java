package BaiThucHanhOOP.TH3.Bai6;

public class HinhTron implements DoiTuongHinhHoc {
    float banKinh;
    final float pi = 3.14f;

    public HinhTron(float banKinh) {
        this.banKinh = banKinh;
    }

    @Override
    public float tinhDienTich() {
        float dienTich;
        dienTich = (float) (pi * Math.pow(banKinh,2));

        return dienTich;

    }

    @Override
    public float tinhChuVi() {
        float chuVi;
        chuVi = 2 * pi * banKinh;

        return chuVi;
    }
}

package BaiThucHanhOOP.TH3.Bai6;

public class HinhTronThayDoi extends HinhTron implements ThayDoiKichThuoc {


    public HinhTronThayDoi(float banKinh) {
        super(banKinh);
    }

    @Override
    public float thayDoiKt(float thaydoi) {
        banKinh += thaydoi/100f;
        return banKinh ;
    }
}

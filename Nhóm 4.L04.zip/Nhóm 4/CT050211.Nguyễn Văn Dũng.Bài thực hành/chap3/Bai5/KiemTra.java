package BaiThucHanhOOP.TH3.Bai5;

public class KiemTra {
    public static void main(String[] args) {
        DiemDiChuyen tam = new DiemDiChuyen(2f,2f,3f,1f);
        HinhTronDiChuyen o = new HinhTronDiChuyen(3f,tam);

        System.out.println(tam.toString());

        o.diLen();
        o.diXuong();
    }
}

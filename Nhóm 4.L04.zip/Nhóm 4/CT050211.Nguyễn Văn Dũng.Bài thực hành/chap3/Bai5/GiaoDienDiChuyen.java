package BaiThucHanhOOP.TH3.Bai5;

public interface GiaoDienDiChuyen {
    public void diLen();

    public void diXuong();

    public void sangTrai();

    public void sangPhai();

}

package BaiThucHanhOOP.TH3.Bai5;

public class HinhTronDiChuyen implements GiaoDienDiChuyen {
    float r;
    DiemDiChuyen tam;

    public HinhTronDiChuyen(float r, DiemDiChuyen tam) {
        this.r = r;
        this.tam = tam;
    }

    @Override
    public String toString() {
        return "HinhTronDiChuyen{" +
                "r=" + r +
                ", tam=" + tam +
                '}';
    }

    @Override
    public void diLen() {
        if (tam.v_x > 0) {
            System.out.print("Hinh tron di len.");
        } else
            System.out.print("Hinh tron ko di len.");
    }

    @Override
    public void diXuong() {
        if (tam.v_x < 0) {
            System.out.print("Hinh tron di xuong.");
        } else
            System.out.print("Hinh tron khong di xuong.");
    }

    @Override
    public void sangTrai() {
        if (tam.v_y < 0) {
            System.out.print("Hinh tron sang trai.");
        } else
            System.out.print("Hinh tron khong sang trai.");
    }

    @Override
    public void sangPhai() {
        if (tam.v_y > 0) {
            System.out.print("Hinh tron sang phai.");
        } else
            System.out.print("Hinh tron khong sang phai.");
    }
}

package BaiThucHanhOOP.TH3.Bai5;

public class DiemDiChuyen implements GiaoDienDiChuyen {
    float x;
    float y;
    float v_x;
    float v_y;

    public DiemDiChuyen(float x, float y, float v_x, float v_y) {
        this.x = x;
        this.y = y;
        this.v_x = v_x;
        this.v_y = v_y;
    }

    @Override
    public String toString() {
        return "DiemDiChuyen {" +
                "x=" + x +
                ", y=" + y +
                ", v_x=" + v_x +
                ", v_y=" + v_y +
                '}';
    }
    public void diLen() {
        if (v_x>0)
            System.out.print("Diem di len.");
    }
    @Override
    public void diXuong() {
        if (v_x < 0) {
            System.out.print("Diem di xuong.");
        }
    }
    @Override
    public void sangTrai() {
        if (v_y<0) {
            System.out.print("Diem di sang trai.");
        }
    }

    @Override
    public void sangPhai() {
        if (v_y > 0) {
            System.out.print("Diem di sang phai.");
        }
    }
}

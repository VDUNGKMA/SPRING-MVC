package BaiThucHanhOOP.TH3.Bai4;

public class DiemDiChuyen extends Diem {
    float v_x;
    float v_y;

    public DiemDiChuyen() {
    }

    public DiemDiChuyen(float x, float y, float v_x, float v_y) {
        super(x, y);
        this.v_x = v_x;
        this.v_y = v_y;
    }

    public DiemDiChuyen(float v_x, float v_y) {
        this.v_x = v_x;
        this.v_y = v_y;
    }

    public float getV_x() {
        return v_x;
    }

    public float getV_y() {
        return v_y;
    }

    public void setV_x(float v_x) {
        this.v_x = v_x;
    }

    public void setV_y(float v_y) {
        this.v_y = v_y;
    }
    public void diChuyen(float time) {
        System.out.print("Toa do truoc di chuyen: ("+this.x+","+this.y+")\n");
        float s_x,s_y;

            s_x = this.x + v_x * time;
            s_y = this.y + v_y * time;

            System.out.print("Toa do sau di chuyen: ("+s_x+","+s_y+")");
        }
    }

package BaiThucHanhOOP.TH3.Bai4;

public class Diem {
    float x;
    float y;

    public Diem() {
    }
    public Diem(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setX(float x) {
        this.x = x;
    }

    @Override
    public String toString() {
        return "Diem {" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
}

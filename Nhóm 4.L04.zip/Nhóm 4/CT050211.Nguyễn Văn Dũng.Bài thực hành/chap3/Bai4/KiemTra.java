package BaiThucHanhOOP.TH3.Bai4;

public class KiemTra {
    public static void main(String[] args) {
        DiemDiChuyen a = new DiemDiChuyen(1f,1f,2f,5);

        a.diChuyen(5f);
    }
}

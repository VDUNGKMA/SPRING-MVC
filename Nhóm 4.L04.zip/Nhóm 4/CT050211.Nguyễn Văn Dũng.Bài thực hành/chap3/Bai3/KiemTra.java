package BaiThucHanhOOP.TH3.Bai3;



public class KiemTra {
    public static void main(String[] args) {
        KhachHang kh1 = new KhachHang("111", "Huy", "HN", 2000f);
        KhachHangTX tx1 = new KhachHangTX("112", "Hieu", "BN", 2500f, 0.15f);

        System.out.print(tx1.toString()+"\n");
        System.out.print(tx1.tinhTienSauGiamGia());
    }


}

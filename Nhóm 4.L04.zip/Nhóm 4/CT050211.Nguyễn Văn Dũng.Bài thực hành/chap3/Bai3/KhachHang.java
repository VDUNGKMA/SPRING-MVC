package BaiThucHanhOOP.TH3.Bai3;

public class KhachHang {
    String maKhachHang;
    String hoTen;
    String diaChi;
    float tienTra;

    public KhachHang(String maKhachHang, String hoTen, String diaChi, float tienTra) {
        this.maKhachHang = maKhachHang;
        this.hoTen = hoTen;
        this.diaChi = diaChi;
        this.tienTra = tienTra;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public void setTienTra(float tienTra) {
        this.tienTra = tienTra;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public String getHoTen() {
        return hoTen;
    }

    public String getMaKhachHang() {
        return maKhachHang;
    }

    public float getTienTra() {
        return tienTra;
    }

    @Override
    public String toString() {
        return "KhachHang { " +
                "maKhachHang='" + maKhachHang + '\'' +
                ", hoTen='" + hoTen + '\'' +
                ", diaChi='" + diaChi + '\'' +
                ", tienTra=" + tienTra +
                '}';
    }
}

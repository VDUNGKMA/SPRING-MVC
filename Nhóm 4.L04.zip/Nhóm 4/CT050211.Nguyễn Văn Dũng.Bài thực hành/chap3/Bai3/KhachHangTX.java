package BaiThucHanhOOP.TH3.Bai3;

public class KhachHangTX extends KhachHang {
     float giamGia;

    public KhachHangTX(String maKhachHang, String hoTen, String diaChi, float tienTra, float giamGia) {
        super(maKhachHang, hoTen, diaChi, tienTra);
        this.giamGia = giamGia;
    }

    public float getGiamGia() {
        return giamGia;
    }

    public void setGiamGia(float giamGia) {
        this.giamGia = giamGia;
    }
    public float tinhTienSauGiamGia() {
        tienTra = tienTra - tienTra*giamGia;
        return tienTra;
    }

    @Override
    public String toString() {
        return "KhachHangTX{" +
                "giamGia=" + giamGia +
                ","+ super.toString();
    }
}
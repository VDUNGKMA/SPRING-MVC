package BaiThucHanhOOP.TH3.Bai1;

public class KiemTra {
    public static void main( String[] args) {
        HinhTron ht1 = new HinhTron(2.5f);
        HinhTru hinhTru = new HinhTru(2.5f,3f);

        System.out.print("Dien tich hinh tru: "+ hinhTru.tinhDienTich());
        System.out.println();
        System.out.print(ht1.toString());
        System.out.println();
        System.out.print("Dien tich hinh tron: "+ht1.tinhDienTich());
        System.out.println();
        System.out.print(hinhTru.toString());
    }
}





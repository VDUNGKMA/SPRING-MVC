package BaiThucHanhOOP.TH3.Bai1;

public class HinhTru extends HinhTron {
    private float chieuCao;

    public HinhTru(float chieuCao) {
        this.chieuCao = chieuCao;
    }

    public HinhTru(float banKinh, float chieuCao) {
        super(banKinh);
        this.chieuCao = chieuCao;
    }

    public void setChieuCao(float chieuCao) {
        this.chieuCao = chieuCao;
    }

    public float getChieuCao() {
        return chieuCao;
    }
    public float tinhDienTich() {
        final float pi = 3.14f;
        float dientich;
        dientich = 2*pi*getBanKinh()*(getBanKinh()+chieuCao);

        return dientich;
    }

    public String toString() {
        return "Hinh tru: Chieu cao - "+getChieuCao()+" Ban kinh: "+super.toString();
    }
}

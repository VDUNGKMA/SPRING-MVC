/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
    
public class Sum3Model {
    private int a;
    private int b;
    private int c;
    private int tong;
    public Sum3Model() {
        this.a = 0;
        this.b = 0;
        this.c = 0;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public int getTong() {
        return tong;
    }

    public void tinhTong() {
        this.tong = this.a+this.b+this.c;
    }

}

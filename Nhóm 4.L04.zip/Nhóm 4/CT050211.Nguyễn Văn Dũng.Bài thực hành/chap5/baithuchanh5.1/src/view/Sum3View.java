/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.Sum3Listener;
import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Sum3Model;

public class Sum3View extends JFrame {
    private JTextField jTextField_A;
    private JTextField jTextField_B;
    private JTextField jTextField_C;
    private JTextField jTextField_KetQua;
    private Sum3Model sum3Model;

    public Sum3View(){
        
        this.sum3Model = new Sum3Model();
        this.init();    
        this.setVisible(true);
    }

    private void init() {
        this.setTitle("Tính tong 3 so");
        this.setSize(300,300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel jLabel_A= new JLabel("A:");
        JLabel jLabel_B=new JLabel("B:");
        JLabel jLabel_C=new JLabel("C:");
        Sum3Listener sum3Listener=new Sum3Listener(this);
        JButton jButton_KetQua=new JButton("Ket qua");
        jButton_KetQua.addActionListener(sum3Listener);
        
        JPanel jPanel =new JPanel();
        jPanel.setLayout(new GridLayout(4,2,10,10));
        jPanel.add(jLabel_A);jPanel.add(jTextField_A=new JTextField(10));
        jPanel.add(jLabel_B);jPanel.add(jTextField_B=new JTextField(10));
        jPanel.add(jLabel_C);jPanel.add(jTextField_C=new JTextField(10));
        jPanel.add(jButton_KetQua);jPanel.add(jTextField_KetQua=new JTextField(10));
        this.setLayout(new BorderLayout());
        this.add(jPanel,BorderLayout.CENTER);
        
        
    }
    public void tong(){
        int firstValue=Integer.valueOf(jTextField_A.getText());
        int secondValue=Integer.valueOf(jTextField_B.getText());
        int thirdValue=Integer.valueOf(jTextField_C.getText());
        this.sum3Model.setA(firstValue);
        this.sum3Model.setB(secondValue);
        this.sum3Model.setC(thirdValue);
        this.sum3Model.tinhTong();
        this.jTextField_KetQua.setText(this.sum3Model.getTong()+"");
    }
    
    

    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import model.Sum3Model;
import view.Sum3View;

public class test {
    public static void main(String[] args) {
        Sum3View s3v=new Sum3View();
        
    }
}

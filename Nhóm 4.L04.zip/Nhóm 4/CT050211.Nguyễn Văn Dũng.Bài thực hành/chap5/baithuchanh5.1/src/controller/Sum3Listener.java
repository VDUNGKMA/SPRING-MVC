/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import view.Sum3View;

public class Sum3Listener implements ActionListener{
    private Sum3View sum3view;

    public Sum3Listener(Sum3View sum3view) {
        this.sum3view = sum3view;
    }

    

    
   
    @Override
    public void actionPerformed(ActionEvent e) {
        String button = e.getActionCommand();
        if(button.equals("Ket qua")){
            this.sum3view.tong();
        }
    }
    
}

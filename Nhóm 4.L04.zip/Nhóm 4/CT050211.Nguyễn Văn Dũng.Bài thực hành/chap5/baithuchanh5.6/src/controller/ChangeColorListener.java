/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.ChangeColorView;


public class ChangeColorListener implements ActionListener {

    private ChangeColorView changeColorView;

    public ChangeColorListener(ChangeColorView changeColorView) {
        this.changeColorView = changeColorView;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String button = e.getActionCommand();
        if (button.equals("Red")) {
            this.changeColorView.changeColor(Color.RED);
            System.out.println("red");

        } else if (button.equals("Blue")) {
            this.changeColorView.changeColor(Color.BLUE);

        } else if (button.equals("Green")) {
            this.changeColorView.changeColor(Color.GREEN);

        } else if (button.equals("Pink")) {
            this.changeColorView.changeColor(Color.PINK);

        } else if (button.equals("Black")) {
            this.changeColorView.changeColor(Color.BLACK);

        } else if (button.equals("Quit")) {
            System.exit(0);
        } else if (button.equals("Erase")) {
            this.changeColorView.changeColor(Color.WHITE);
        }
    }

}

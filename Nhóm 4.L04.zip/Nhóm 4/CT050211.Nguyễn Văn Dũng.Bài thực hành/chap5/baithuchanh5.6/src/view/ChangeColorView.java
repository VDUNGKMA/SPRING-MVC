/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.ChangeColorListener;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class ChangeColorView extends JFrame{
    private JLabel jLabel_File;
    private JLabel jLabel_Edit;
    private JLabel jLabel_Color;

    public ChangeColorView() {
        this.init();
        this.setVisible(true);
    }
    public void init(){
        this.setTitle("Ð?i màu");
        this.setSize(600, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //header
        JPanel jPanel_Header=new JPanel();
        jPanel_Header.setLayout(new GridLayout(1, 3));
        jLabel_File=new JLabel("File",SwingConstants.CENTER);
        jLabel_Edit=new JLabel("Edit",SwingConstants.CENTER);
        jLabel_Color=new JLabel("Color",SwingConstants.CENTER);
        jPanel_Header.add(jLabel_File);
        jPanel_Header.add(jLabel_Edit);
        jPanel_Header.add(jLabel_Color);
        //content
        JPanel jPanel_Content=new JPanel();
        jPanel_Content.setLayout(new GridLayout(1, 3));
        
        JPanel jPanel_Color=new JPanel();
        jPanel_Color.setLayout(new GridLayout(5,1));
        ChangeColorListener changeColorListenter=new ChangeColorListener(this);
        JButton jButton_Red=new JButton("Red");jButton_Red.addActionListener(changeColorListenter);
        jPanel_Color.add(jButton_Red);
        JButton jButton_Green=new JButton("Green");jButton_Green.addActionListener(changeColorListenter);
        jPanel_Color.add(jButton_Green);
        JButton jButton_Blue=new JButton("Blue");jButton_Blue.addActionListener(changeColorListenter);
        jPanel_Color.add(jButton_Blue);
        JButton jButton_Pink=new JButton("Pink");jButton_Pink.addActionListener(changeColorListenter);
        jPanel_Color.add(jButton_Pink);
        JButton jButton_Black=new JButton("Black");jButton_Black.addActionListener(changeColorListenter);
        jPanel_Color.add(jButton_Black);
        
        JButton jButton_Quit =new JButton("Quit");jButton_Quit.addActionListener(changeColorListenter);
        JButton jButton_Erase =new JButton("Erase");jButton_Erase.addActionListener(changeColorListenter);
        jPanel_Content.add(jButton_Quit);
        jPanel_Content.add(jButton_Erase);
        jPanel_Content.add(jPanel_Color);
        this.setLayout(new GridLayout(3,1));
        this.add(jPanel_Header);
        this.add(jPanel_Content);
        this.setBackground(Color.WHITE);
    }
    public void changeColor(Color color){
        this.getContentPane().setBackground(color);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.RandomListener;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import model.RandomModel;


public class RandomView extends JFrame {
    private JTextField  jTextField;
    private RandomModel randomModel;
    private JLabel jLabel_Correct;
    private JLabel jLabel_FirstValue;
    private JLabel jLabel_SecondValue;
    private JLabel jLabel_Subtend;
    public RandomView() {
        this.randomModel = new RandomModel();
        this.init();
        this.setVisible(true);
    }
    public void init(){
        this.setTitle("Tinh nham");
        this.setSize(300,300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JPanel jPanelHeader=new JPanel();
        jLabel_FirstValue=new JLabel();jLabel_FirstValue.setText(randomModel.getFirstValue()+"");
        jLabel_Subtend=new JLabel();jLabel_Subtend.setText(randomModel.getSubtend()+"");
        jLabel_SecondValue=new JLabel();jLabel_SecondValue.setText(randomModel.getSecondValue()+"");
        JLabel jLabel_Equal=new JLabel("=");
        jTextField=new JTextField();
        
        jPanelHeader.setLayout(new GridLayout(1,5));
        jPanelHeader.add(jLabel_FirstValue);
        jPanelHeader.add(jLabel_Subtend);
        jPanelHeader.add(jLabel_SecondValue);
        jPanelHeader.add(jLabel_Equal);
        jPanelHeader.add(jTextField);
        
        RandomListener randomListener=new RandomListener(this);
        
        jLabel_Correct=new JLabel("",SwingConstants.CENTER);
        
        JPanel jPanel_Footer=new JPanel();
        jPanel_Footer.setLayout(new GridLayout(1,2));
        JButton jButton_OK=new JButton("OK");jPanel_Footer.add(jButton_OK);jButton_OK.addActionListener(randomListener);
        JButton jButton_Next=new JButton("Next");jPanel_Footer.add(jButton_Next);jButton_Next.addActionListener(randomListener);
        
        this.setLayout(new GridLayout(3,1));
        this.add(jPanelHeader);
        this.add(jLabel_Correct);
         this.add(jPanel_Footer);
    }
    public void checkCorrect(){
        int result=Integer.valueOf(jTextField.getText());
        if(result==randomModel.getResult()){
            jLabel_Correct.setText("Lam dung r e");
        }else{
            jLabel_Correct.setText("Lam sai r e");
        }
    }
    public void next(){
        this.randomModel.reset();
        this.jLabel_FirstValue.setText(randomModel.getFirstValue()+"");
        this.jLabel_SecondValue.setText(randomModel.getSecondValue()+"");
        this.jLabel_Subtend.setText(randomModel.getSubtend()+"");
        this.jLabel_Correct.setText("");
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Random;


public class RandomModel {
    private int firstValue;
    private int secondValue;
    private char subtend;
    private int result;

    public RandomModel() {
        
        char[] sub={'+','-','*','/'};
        Random random=new Random();
        
        firstValue=random.nextInt(100);
        secondValue=random.nextInt(100);
        subtend=sub[random.nextInt(4)];
        if(subtend=='+'){
            result=firstValue+secondValue;
        }else if(subtend=='-'){
            result=firstValue-secondValue;
        }else if(subtend=='*'){
            result=firstValue*secondValue;
        }else if(subtend=='/'){
            result=firstValue/secondValue;
        }
    }

    public int getFirstValue() {
        return firstValue;
    }

    public void setFirstValue(int firstValue) {
        this.firstValue = firstValue;
    }

    public int getSecondValue() {
        return secondValue;
    }

    public void setSecondValue(int secondValue) {
        this.secondValue = secondValue;
    }

    public char getSubtend() {
        return subtend;
    }

    public void setSubtend(char subtend) {
        this.subtend = subtend;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
    public void reset(){
        char[] sub={'+','-','*','/'};
        Random random=new Random();
        
        firstValue=random.nextInt(100);
        secondValue=random.nextInt(100);
        subtend=sub[random.nextInt(4)];
        if(subtend=='+'){
            result=firstValue+secondValue;
        }else if(subtend=='-'){
            result=firstValue-secondValue;
        }else if(subtend=='*'){
            result=firstValue*secondValue;
        }else if(subtend=='/'){
            result=firstValue/secondValue;
        }
    }
    
}

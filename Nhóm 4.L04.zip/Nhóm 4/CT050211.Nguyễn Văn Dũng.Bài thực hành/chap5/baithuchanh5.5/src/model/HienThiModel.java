/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class HienThiModel {
    private int n;
    private String ketqua;

    public HienThiModel( ) {
        this.n = 0;
        this.ketqua = "";
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public String getKetqua() {
        return ketqua;
    }

    public void setKetqua(String ketqua) {
        this.ketqua = ketqua;
    }
    
    public void showKetQua(){
        for(int i=1;i<=n;i++){
            if(i!=n){
                this.ketqua+=i+", ";
            }else{
                this.ketqua+=i+"";
            }
            
            
        }
    }
    
}

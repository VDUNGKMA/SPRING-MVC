/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.HienThiListener;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import model.HienThiModel;


public class HienThiView extends JFrame {
    private JTextField jTextField;
    private JTextArea jTextArea;
    private HienThiModel hienThiModel;

    public HienThiView() {
        
        hienThiModel=new HienThiModel();
        this.init();
        this.setVisible(true);
    }
    public void init(){
        setTitle("Hi?n th? s? nguyên");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        HienThiListener hienThiListener=new HienThiListener(this);
        JButton jButton=new JButton("Show");
        jButton.addActionListener(hienThiListener);
        jTextField=new JTextField("");
        JPanel jPanel=new JPanel();
        jPanel.setLayout(new GridLayout(1, 2, 10, 20));
        jPanel.add(jTextField);
        jPanel.add(jButton);
        
        jTextArea=new JTextArea("");
        
        this.setLayout(new BorderLayout());
        this.add(jPanel,BorderLayout.NORTH);
        this.add(jTextArea,BorderLayout.CENTER);
    }
    public void showKetQua(){
        int so=Integer.valueOf(this.jTextField.getText());
        this.hienThiModel.setN(so);
        this.hienThiModel.showKetQua();
        this.jTextArea.setText(this.hienThiModel.getKetqua());
    }
}

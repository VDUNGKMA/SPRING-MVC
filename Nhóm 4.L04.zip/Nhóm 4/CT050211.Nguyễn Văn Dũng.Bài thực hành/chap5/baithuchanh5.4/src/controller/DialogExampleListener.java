/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Action;
import javax.swing.JColorChooser;
import javax.swing.JOptionPane;
import view.DialogExampleView;

public class DialogExampleListener implements ActionListener {

    private DialogExampleView dEV;
    @Override
    public void actionPerformed(ActionEvent e) {
        String button=e.getActionCommand();
        if(button!=null){
            dEV.setTextDialog(button);
            JOptionPane.showMessageDialog(dEV, "mày dang an nut :"+button, "thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public DialogExampleListener(DialogExampleView dEV) {
        this.dEV = dEV;
    }
    
}

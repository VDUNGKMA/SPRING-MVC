/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.DialogExampleListener;
import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import model.DialogExampleModel;


public class DialogExampleView extends JFrame {
   
    private JLabel jLabel;
    private DialogExampleModel dialogExampleModel;
    public DialogExampleView(){
        this.dialogExampleModel=new DialogExampleModel();
        this.init();
        this.setVisible(true);
    }
    public void init(){
        this.setTitle("DialogExample");
        this.setSize(500, 500);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel jPanel=new JPanel();
        DialogExampleListener dEL=new DialogExampleListener(this);
        JButton jButton_Senior=new JButton("Senior");
        JButton jButton_Junior=new JButton("Junior");
        JButton jButton_Sophomore=new JButton("Sophomore");
        JButton jButton_Freshman=new JButton("Freshman");
        jButton_Senior.addActionListener(dEL);
        jButton_Junior.addActionListener(dEL);
        jButton_Sophomore.addActionListener(dEL);
        jButton_Freshman.addActionListener(dEL);
        

        jLabel=new JLabel("");

        jPanel.setLayout(new GridLayout(4,3,50,30));
        jPanel.add(new JLabel());
        jPanel.add(jButton_Senior);
        jPanel.add(new JLabel());
        
        jPanel.add(new JLabel());
        jPanel.add(jButton_Junior);
        jPanel.add(new JLabel());
        
        jPanel.add(new JLabel());
        jPanel.add(jButton_Sophomore);
        jPanel.add(new JLabel());
        
        jPanel.add(new JLabel());
        jPanel.add(jButton_Freshman);
        jPanel.add(new JLabel());
        this.setLayout(new BorderLayout());
        this.add(jPanel,BorderLayout.CENTER);
        
    }
    public void setTextDialog(String button){
        dialogExampleModel.setType(button);
        String text=dialogExampleModel.getType();
        
    }
}

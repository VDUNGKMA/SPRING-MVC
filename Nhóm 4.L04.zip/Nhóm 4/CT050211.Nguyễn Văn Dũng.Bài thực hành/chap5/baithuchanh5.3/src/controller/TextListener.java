/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.TextView;

public class TextListener implements ActionListener{

    private TextView tview ;

    public TextListener(TextView tview) {
        this.tview = tview;
    }

    
    
    @Override
    public void actionPerformed(ActionEvent e) {
       String button=e.getActionCommand();
       if(button.equals("Thay doi")){
           this.tview.changeTittle();
       }
    }
    
}

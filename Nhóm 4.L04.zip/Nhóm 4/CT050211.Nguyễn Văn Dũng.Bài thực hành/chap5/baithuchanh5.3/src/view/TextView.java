/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import controller.TextListener;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class TextView  extends JFrame{
    private JButton jButton;
    private  JTextField jTextField;
    public TextView(){
        this.init();
        this.setVisible(true);
    }
    public void init(){
        this.setTitle("Tieu de trong");
        this.setSize(400,450);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        TextListener tListener=new TextListener(this);
        jButton=new JButton("Thay doi");
        jButton.addActionListener(tListener);
        jTextField=new JTextField();
        this.setLayout(new GridLayout(1,2,0,20));
        this.add(jButton );
        this.add(jTextField );     
    }
    public void changeTittle(){
        String text=this.jTextField.getText();
        this.setTitle(text);
    }
}

package bai1_th4;

import java.io.IOException;
import java.util.Scanner;
public class bai1  {
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws RuntimeException {
		System.out.print("Nhập hệ số  a = ");
        float a = bai1.scanner.nextFloat();
        System.out.print("Nhập hệ số b = ");
        float b = bai1.scanner.nextFloat();
        System.out.print("Nhập hệ số c = ");
        float c = scanner.nextFloat();
        bai1.giaiPTBac2(a, b, c);
    }
    public static void giaiPTBac2(float a, float b, float c) {
        // kiểm tra các hệ số
    	try {
        if (a == 0) {
            if (b == 0) {
                System.out.println("phương trình vô nghiệm");
            } else {
                System.out.println("pt có 1 nghiệm: "
                        + "x = " + (-c / b));
            }
            return;
        }
        // tính delta
        float delta = b*b - 4*a*c;
        float x1;
        float x2;
        // tính nghiệm
        if (delta > 0) {
            x1 = (float) ((-b + Math.sqrt(delta)) / (2*a));
            x2 = (float) ((-b - Math.sqrt(delta)) / (2*a));
            System.out.println("pt có 2 nghiệm pb�: "
                    + "x1 = " + x1 + " và x2 = " + x2);
        } else if (delta == 0) {
            x1 = (-b / (2 * a));
            System.out.println("pt có nghiệm kép: "
                    + "x1 = x2 = " + x1);
        } else {
            System.out.println("pt vô nghiệm");
        }
    }catch (ArithmeticException aex) {
    	System.out.println("Loi: " + aex.getMessage() + " xay ra.");
    	aex.printStackTrace();
    	}
	
	}
}

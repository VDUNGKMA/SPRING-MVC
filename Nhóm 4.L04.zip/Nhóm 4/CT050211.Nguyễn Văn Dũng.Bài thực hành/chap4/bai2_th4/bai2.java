package bai2_th4;

import java.util.Scanner;

public class bai2 {
	public static void main(String[] args) {
		ExampleException obj = new ExampleException();
		
		try {
			obj.nhap();
			
		} catch (MyException e) {
	        System.out.println(e.getMessage());
		}
		
	}

}

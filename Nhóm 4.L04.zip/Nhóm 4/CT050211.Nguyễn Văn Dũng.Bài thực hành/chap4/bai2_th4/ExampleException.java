package bai2_th4;

import java.util.Scanner;
public class ExampleException 
{
    public static void nhap() throws MyException 
    {	
    	Scanner scanner = new Scanner(System.in);
    	int ngay,thang,nam;
    	System.out.print("Nhap vao ngay: ");
		ngay=scanner.nextInt();
		System.out.print("Nhap vao thang: ");
		thang=scanner.nextInt();
		System.out.print("Nhap vao nam: ");
		nam=scanner.nextInt();
  

        if (ngay <1||ngay>31) { 
           throw new MyException("Nhap sai dinh dang ngay"); // tung ngoại lệ
        }
        if (thang<1||thang>12) {
        	throw new MyException("Nhap sai dinh dang thang"); // tung ngoại lệ
        }
        
        System.out.println("Nhap hoan tat");
        System.out.println(ngay+"/"+thang+"/"+nam);
    }
}
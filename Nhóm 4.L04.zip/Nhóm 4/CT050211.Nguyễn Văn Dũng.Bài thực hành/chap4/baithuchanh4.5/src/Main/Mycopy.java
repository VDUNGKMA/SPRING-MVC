/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 *
 * @author ADMIN
 */
public class Mycopy {

    public static void main(String[] args) {
        File filename1 = new File("C:\\NetBeans\\Thuchanh4.5\\file1");
        File filename2 = new File("C:\\NetBeans\\Thuchanh4.5\\file2");

        if (filename1.isFile() && filename2.isFile()) {
            try {
                Files.copy(filename1.toPath(), filename2.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception e) {
                System.out.println(e);
            }
        }else if(filename1.isFile() && filename2.isDirectory()){
            
        }

    }
}
